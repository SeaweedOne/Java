import java.util.Arrays;
import java.util.Scanner;

public class FinalTest_2 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		String input1 = s.nextLine();
		String input2 = s.nextLine();

		String[] temp1 = input1.split(" ");
		String[] temp2 = input2.split(" ");

		int len = temp1.length;
		int[] arr1 = new int[len];
		int[] arr2 = new int[len];

		for (int i = 0; i < len; i++) {
			arr1[i] = Integer.parseInt(temp1[i]);
			arr2[i] = Integer.parseInt(temp2[i]);
		}

		Arrays.sort(arr1);
		Arrays.sort(arr2);

		String result = "T";

		for (int i = 0; i < len; i++) {
			if (arr1[i] != arr2[i]) {
				result = "F";
			}
		}

		System.out.println(result);

	}

}
