import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class FinalTest_1 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		String input = s.nextLine(); //사용자인풋받기 
		String[] temp = input.split(",");  //컴마를 기준으로 나눠주기 

		int len = (temp.length); //배열의 길이 변수에 넣어주기 (깔끔한 코드를 위해!)

		int D = 0; //D값 초기 설정 
		int[] arr = new int[len - 1]; //배열 초기 설정 (D가 빠질예정이니 temp길이 -1)

		for (int i = 0; i < len; i++) { //포문돌며 임시 배열의 값 정수형으로 변환
			if (i == 0) {
				D = Integer.parseInt(temp[0]); //첫번째 값은 D
			} else {
				arr[i - 1] = Integer.parseInt(temp[i]); //나머지 값은 배열 
			}
		}

		Arrays.sort(arr); // 정렬 

		for (int i = 0; i < arr.length; i++) { 
			if (arr[i] % D == 0) { //포문돌며 배열의 값 D로 나눠 나머지가 0이라면 출력 
				if (i == (arr.length - 1)) { //마지막값이라면 콤마없이 출력 
					System.out.print(arr[i]);
				} else {
					System.out.print(arr[i]); // 마지막 값이 아니라면 콤마와 함께 출력 
					System.out.print(", ");
				}
			}

		}

	}

}
